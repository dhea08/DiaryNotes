package com.example.privatenotesdiary;

public class NotesBuilder {

    private String title;
    private String content;
    private String createdDate;
    private String updatedDate;
    private String contentOnly;
    String notes_id;


    public String getNotes_id() {
        return notes_id;
    }

    public void setNotes_id(String notes_id) {
        this.notes_id = notes_id;
    }

    public String getContentOnly() {
        contentOnly = "";
        String[] arrOfStr = content.split("\\|\\|\\|\\|\\|");
        if(arrOfStr.length>1){
            if(!arrOfStr[1].equals("")){
                contentOnly = arrOfStr[1];
            }
        }

        if(contentOnly.length() > 20){
            contentOnly = contentOnly.substring(0,20) + "...";
        }
        return contentOnly;
    }

    public void setContentOnly(String contentOnly) {
        this.contentOnly = contentOnly;
    }

    public String getCreatedDate() {

        createdDate = "";
        String[] arrOfStr = content.split("\\|\\|\\|\\|\\|");
        if(arrOfStr.length>0){
            if(!arrOfStr[0].equals("")){
              String  strDate = arrOfStr[0];
              String[] arrofDate = strDate.split("\\#\\#\\#\\#\\#");
                if(arrofDate.length>0) {
                    if (!arrofDate[0].equals("")) {
                        createdDate = arrofDate[0];
                    }
                }
            }
        }
        return createdDate;
    }

    public String getUpdatedDate() {
        updatedDate = "";
        String[] arrOfStr = content.split("\\|\\|\\|\\|\\|");
        if(arrOfStr.length>0){
            if(!arrOfStr[0].equals("")){
                String  strDate = arrOfStr[0];
                String[] arrofDate = strDate.split("\\#\\#\\#\\#\\#");
                if(arrofDate.length>1) {
                    if (!arrofDate[1].equals("")) {
                        updatedDate = arrofDate[1];
                    }
                }
            }
        }
        return updatedDate;
    }

    public NotesBuilder() {
    }

    public NotesBuilder(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public NotesBuilder(String title, String content,String notes_id) {
        this.title = title;
        this.content = content;
        this.notes_id = notes_id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
