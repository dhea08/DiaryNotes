package com.example.privatenotesdiary;

import android.app.Activity;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.privatenotesdiary.R;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {

    SharedPreferences settings;
    String password_session,name_session;
    TextView FirstMessage,change_user;
    ProgressBar loadingProgressBar;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
       loadingProgressBar = findViewById(R.id.loading);

        FirstMessage = findViewById(R.id.FirstMessage);
        settings = getSharedPreferences("Dhea", MODE_PRIVATE);
        // Reading from SharedPreferences
        password_session = settings.getString("password", "");
        name_session = settings.getString("name", "");

        if(name_session.equals("")){
            //belum pernah login

        }else{
            //udah pernah login
            usernameEditText.setText(name_session);
            usernameEditText.setEnabled(false);
            FirstMessage.setText("Hi " + name_session +", silakan masukkan password untuk memastikan benar anda yang membuka aplikasi ini");
        }

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                    if(!usernameEditText.getText().equals("")&&!passwordEditText.getText().equals("")){
                        loginButton.setEnabled(true);
                    }else{
                        loginButton.setEnabled(false);
                    }
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {

                }
                return false;
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
               bukaAplikasi(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        });

        change_user = findViewById(R.id.changeUser);
        change_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("name", "");
                editor.putString("password", "");
                editor.commit();
                usernameEditText.setEnabled(true);
                usernameEditText.setText("");
                FirstMessage.setText(getResources().getString(R.string.First_Message));
            }
        });
    }
void session_isi(String username,String Password,String responses){
    if(name_session.equals("")||responses.equals("2")){
        //pertama kali
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("name", username);
        editor.putString("password", Password);
        editor.commit();
        loadingProgressBar.setVisibility(View.GONE);
        Intent intent = new Intent(LoginActivity.this , PilihCatatan.class);
        startActivity(intent);
        finish();

    }else{
        //udah pernah
             loadingProgressBar.setVisibility(View.GONE);
            Intent intent = new Intent(LoginActivity.this , PilihCatatan.class);
            startActivity(intent);
            finish();
    }
}
    void bukaAplikasi(final String username, final String password){
        String  url = new Constants().api_user;
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("dhea  Response", response);
                        if(response.equals("1") || response.equals("2") ){
                           session_isi(username,password,response);
                        }else{
                            showLoginFailed(R.string.salah_password);
                            loadingProgressBar.setVisibility(View.GONE);
                        }
                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("dhea Error.Response", error.getMessage());
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(postRequest);
    }
    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}
