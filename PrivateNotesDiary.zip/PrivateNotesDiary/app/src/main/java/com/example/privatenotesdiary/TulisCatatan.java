package com.example.privatenotesdiary;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.text.format.DateUtils;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.dankito.richtexteditor.android.RichTextEditor;
import net.dankito.richtexteditor.android.toolbar.AllCommandsEditorToolbar;
import net.dankito.richtexteditor.callback.GetCurrentHtmlCallback;
import net.dankito.richtexteditor.callback.HtmlChangedListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;


public class TulisCatatan extends AppCompatActivity {
    //EditText1,
    EditText txtTitle;
    RichTextEditor editor;
    String CreatedDate = "";
    String UpdatedDate = "";
    int NewFile = 1;
    TextView txtCreatedDate,txtUpdatedDate;

    private AllCommandsEditorToolbar editorToolbar;
    String fileName = "";
    String Notes_id = "";
    String contentdata = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
//        EditText1 = (EditText)findViewById(R.id.EditText1);
        editor = (RichTextEditor) findViewById(R.id.editor);
        txtTitle = (EditText)findViewById(R.id.txtTitle);
        FloatingActionButton fab = findViewById(R.id.fab);


        txtCreatedDate = (TextView)findViewById(R.id.txtCreatedDate);
        txtUpdatedDate = (TextView)findViewById(R.id.txtUpdatedDate);


        editor = (RichTextEditor) findViewById(R.id.editor);

        editorToolbar = (AllCommandsEditorToolbar) findViewById(R.id.editorToolbar);

        editorToolbar.setEditor(editor);
        editorToolbar.setBackgroundColor(getResources().getColor(R.color.dheaHijau));

        editor.setEditorFontSize(20);
        editor.setPadding((int) (4 * getResources().getDisplayMetrics().density));

        editor.setPlaceholder("Tulis Catatan Disini....");

        Intent intent = getIntent();
        String filename_intent = intent.getStringExtra("Filename");
        String notes_intent = intent.getStringExtra("notes_id");
        String content = intent.getStringExtra("content");
        if(filename_intent!=null) {
            fileName = filename_intent;
            Notes_id = notes_intent;
            txtTitle.setText(fileName);
            txtTitle.setEnabled(false);
            contentdata = content;
            NewFile = 0;
        }

//get the attached extras from the intent
//we should use the same key as we used to attach the data.

//if you have used any other type of data, you should use the
//particular getExtra method to extract the data from Intet

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                String filename_intent = intent.getStringExtra("Filename");
                if(filename_intent!=null){
                    fileName = filename_intent;
                    Save(fileName);

                }else{
                    if(fileName.equals("")){
                        fileName = txtTitle.getText().toString();
                        if(fileName.equals("")){

                            txtTitle.requestFocus();
                            Toast.makeText(TulisCatatan.this,"Harap isi title catatannya",
                                    Toast.LENGTH_LONG).show();
                        }else{

                            Save(fileName);

                        }
                    }
                }
            }
        });
        if(!fileName.equals("")){
            editor.setHtml(Open(fileName));

        }


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent myIntent = new Intent(TulisCatatan.this, PilihCatatan.class);
            TulisCatatan.this.startActivity(myIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public static String getDateTimeFromTimeStamp(Long time, String mDateFormat) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(mDateFormat);
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date dateTime = new Date(time);
        return dateFormat.format(dateTime);
    }
    public void Save(final String fileName) {
     editor.getCurrentHtmlAsync(new GetCurrentHtmlCallback() {
            @Override
            public void htmlRetrieved(@NotNull final String html) {
                    try {
                        String  url = "";
                        if(Notes_id.equals("")){
                            url = new Constants().api_insert_notes;
                        }else{
                            url = new Constants().api_update_notes;
                        }
                        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                               Log.e("dhea Response",response);
                                               TulisCatatan.super.onBackPressed();
                                    }
                                }
                                , new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.e("dhea Error.Response", error.getMessage());
                            }
                        } ) {
                            @Override
                            protected Map<String, String> getParams()
                            {
                                Map<String, String>  params = new HashMap<String, String>();
                                SharedPreferences settings = getSharedPreferences("Dhea", MODE_PRIVATE);
                                String name_session = settings.getString("name", "");
                                String createDate = "";
                                String updateDAte = "";
                                String FormatDateTime = "yyyy-MM-dd HH:mm:ss";

                                if(NewFile == 1){
                                    createDate =  getDateTimeFromTimeStamp(System.currentTimeMillis(), FormatDateTime);
                                }else{
                                    createDate = CreatedDate;
                                    updateDAte=  getDateTimeFromTimeStamp(System.currentTimeMillis(), FormatDateTime);

                                }

                             String strData = createDate + "#####" + updateDAte + "|||||" + html;
                                params.put("username", name_session);
                                params.put("title", fileName);
                                params.put("notes_id",Notes_id);
                                params.put("notes",strData);

                                return params;
                            }
                        };
                        RequestQueue queue = Volley.newRequestQueue(TulisCatatan.this);
                        queue.add(postRequest);
                        Toast.makeText(TulisCatatan.this, "Note Saved!", Toast.LENGTH_SHORT).show();
                        } catch (Throwable t) {
                            Toast.makeText(TulisCatatan.this, "Exception: " + t.toString(),
                                    Toast.LENGTH_LONG).show();
                        }
            }
        });
    }

    public String Open(String fileName) {
        String content  = contentdata;
        Log.e("dhea content",contentdata);
                    String[] arrOfStr = content.split("\\|\\|\\|\\|\\|");
                    if(arrOfStr.length>0){
                        if(!arrOfStr[0].equals("")){
                             String  strDate = arrOfStr[0];
                            String[] arrofDate = strDate.split("\\#\\#\\#\\#\\#");
                            if(arrofDate.length>0) {
                                if (!arrofDate[0].equals("")) {
                                    CreatedDate = arrofDate[0];
                                    Log.e("dhea createddate",CreatedDate);
                                }
                            }
                            if(arrofDate.length>1){
                                if (!arrofDate[1].equals("")) {
                                    UpdatedDate = arrofDate[1];
                                    Log.e("dhea updateDAte",UpdatedDate);
                                }
                            }
                        }
                    }
                    if(arrOfStr.length>1){
                        if(!arrOfStr[1].equals("")){
                            content = arrOfStr[1];
                            Log.e("dhea content",content);
                        }
                    }
        return content;
    }

    public boolean FileExists(String fname) {
        File file = getBaseContext().getFileStreamPath(fname);
        return file.exists();
    }
}
