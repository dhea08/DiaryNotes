package com.example.privatenotesdiary;

public class Constants {
    String ip_address_api = "10.0.2.2"; //emulator dan xampp
    String folderApi = "/NotesDiary";
    String api_user = "http://"+ip_address_api+folderApi+"/user.php";
    String api_insert_notes = "http://"+ip_address_api+folderApi+"/insertNotes.php";
    String api_select_notes = "http://"+ip_address_api+folderApi+"/selectNotes.php";
    String api_delete_notes = "http://"+ip_address_api+folderApi+"/deleteNotes.php";
    String api_update_notes = "http://"+ip_address_api+folderApi+"/updateNotes.php";
}
