package com.example.privatenotesdiary;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.MyViewHolder> {

private List<NotesBuilder> notesList;
      Context context;
public class MyViewHolder extends RecyclerView.ViewHolder {
    public TextView title, content,txtCreated,txtUpdated;
    RelativeLayout rl_row;
    ImageView delete_row;

    public MyViewHolder(View view) {
        super(view);
        title = (TextView) view.findViewById(R.id.title);
        content = (TextView) view.findViewById(R.id.content);
        rl_row = (RelativeLayout)view.findViewById(R.id.rl_row);
        delete_row = (ImageView)view.findViewById(R.id.delete_row);
        txtCreated = (TextView)view.findViewById(R.id.txtCreatedDate);
        txtUpdated = (TextView)view.findViewById(R.id.txtUpdatedDate);

    }
}

    public NotesAdapter(List<NotesBuilder> notesList,Context context) {
        this.notesList = notesList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final NotesBuilder note = notesList.get(position);
        holder.title.setText(note.getTitle());
        if(!note.getCreatedDate().equals("")){
            holder.txtCreated.setText("Created :"+note.getCreatedDate());
        }
      if(!note.getUpdatedDate().equals("")){
          holder.txtUpdated.setText("Updated :"+note.getUpdatedDate());
      }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            holder.content.setText(Html.fromHtml(note.getContentOnly(), Html.FROM_HTML_MODE_COMPACT));
        } else {
            holder.content.setText(Html.fromHtml(note.getContentOnly()));
        }
       // holder.content.setText(note.getContent());
//        if(position%2==1){
//            holder.rl_row.setBackgroundColor(context.getResources().getColor(R.color.ganjil));
//        }else{
//            holder.rl_row.setBackgroundColor(context.getResources().getColor(R.color.genap));
//        }
        holder.content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoNotes(note.getTitle(),note.getNotes_id(),note.getContent());
            }
        });
        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoNotes(note.getTitle(),note.getNotes_id(),note.getContent());
            }
        });
        holder.delete_row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteNotes(note.getNotes_id().toString(),position);
            }
        });

    }
void gotoNotes(String FileName, String notes_id,String content){
    //creating and initializing an Intent object
    Intent intent = new Intent(this.context, TulisCatatan.class);
//attach the key value pair using putExtra to this intent

    intent.putExtra("Filename", FileName);
    intent.putExtra("notes_id", notes_id);
    intent.putExtra("content",content);
//starting the activity
    this.context.startActivity(intent);

}
void deleteNotes(final String FileName, final int position){
    String  url = new Constants().api_delete_notes;
    StringRequest postRequest = new StringRequest(Request.Method.POST, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                           Log.e("dhea  Response", response);
                    ( (PilihCatatan)context).prepareNotes();
                }
            }
            , new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.e("dhea Error.Response", error.getMessage());
        }
    }) {
        @Override
        protected Map<String, String> getParams()
        {
            Map<String, String>  params = new HashMap<String, String>();
            params.put("notes_id", FileName);
          return params;
        }
    };
    RequestQueue queue = Volley.newRequestQueue(context);
    queue.add(postRequest);
}
    @Override
    public int getItemCount() {
        return notesList.size();
    }
}
